clear;clc;close all;
%Load match1 as four seperate images
%The respective objects were manually identified using imtool
image = logical(imread('match1.gif'));
clover1 = image(25:110,40:115);
spade1 = image(20:110,115:190);
bull1 = image(115:210,40:115);
plane1 = image(120:205,115:200);
figure;subplot(1,4,1), imshow(clover1);subplot(1,4,2), imshow(spade1);subplot(1,4,3); imshow(bull1); subplot(1,4,4); imshow(plane1);
clover1Dist = sizeDistribution(clover1);
clover1Pect = Pecstrum(clover1Dist);
clover1comp = spectralComplexity(clover1Pect);
spade1Dist = sizeDistribution(spade1);
spade1Pect = Pecstrum(spade1Dist);
spade1comp = spectralComplexity(spade1Pect);
bull1Dist = sizeDistribution(bull1);
bull1Pect = Pecstrum(bull1Dist);
bull1comp = spectralComplexity(bull1Pect);
plane1Dist = sizeDistribution(plane1);
plane1Pect = Pecstrum(plane1Dist);
plane1comp = spectralComplexity(plane1Pect);
figure;
x = 0:20;
plot(x,clover1Dist,x,spade1Dist,x,bull1Dist,x,plane1Dist);
title('Size distribution of reference objects');legend('Clover','Spade','Bull','Plane');
figure; 
plot(x,clover1Pect,x,spade1Pect,x,bull1Pect,x,plane1Pect);
title('Pecstrum of reference objects');legend('Clover','Spade','Bull','Plane');
%Load image to match; objects in image were again manually seperated using
%imtool.
image = logical(imread('match3.gif'));
match3Objects = {image(25:110,50:125),image(25:110,125:200),image(120:220,55:135),image(120:220,135:200)};
%Compute size distributions and pectstrums
figure;subplot(1,4,1), imshow(match3Objects{1});subplot(1,4,2), imshow(match3Objects{2});subplot(1,4,3); imshow(match3Objects{3}); subplot(1,4,4); imshow(match3Objects{4});

match3Dist = {sizeDistribution(match3Objects{1}),sizeDistribution(match3Objects{2}),sizeDistribution(match3Objects{3}),sizeDistribution(match3Objects{4})};
match3Pect = {Pecstrum(match3Dist{1}),Pecstrum(match3Dist{2}),Pecstrum(match3Dist{3}),Pecstrum(match3Dist{4})};
distance = 100;



figure;
plot(x,match3Dist{1},x,match3Dist{2},x,match3Dist{3},x,match3Dist{4});
title('Size distribution of unknown objects');legend('Object 1','Object 2','Object 3','Object 3');
figure; 
plot(x,match3Pect{1},x,match3Pect{2},x,match3Pect{3},x,match3Pect{4});
title('Pecstrum of unknown objects');legend('Object 1','Object 2','Object 3','Object 3');
%Initialize relative weights for pecstralDistance comparison.  Testing
%found that setting all weights to 1 worked sufficiently.
C = ones(1,40);
%find min spectral distance
match3distance(1:4)=0;
for i = 1:4
    match3distance(i) = pecstralDistance(spade1Pect,match3Pect{i},C);
    if  match3distance(i) < distance
        distance = match3distance(i);
        match = i;
    end
end
%Display resulting match
figure;
subplot(1,2,1), imshow(spade1);subplot(1,2,2), imshow(match3Objects{match});
%find min complexity difference
diff = 100;
match3difference(1:4) = 0;
 for i = 1:4
    match3difference(i) = abs(spade1comp - spectralComplexity(match3Pect{i}));
    if  match3difference(i) < diff
        diff = match3difference(i);
        matchComp = i;
    end
 end       
figure;subplot(1,2,1), imshow(spade1);subplot(1,2,2), imshow(match3Objects{matchComp});
%Note that complexity analysis and spectral distance give different result
%To combine the two metrics, we will normalize values to be between 0 and
%1, and then simply sum them.
matchingmetric = (match3distance-mean(match3distance))/std(match3distance) + (match3difference-mean(match3difference))/(std(match3difference));

image = logical( imread('shadow1.gif'));
%Manually extract the 4 solid characters in the original image
Objects = {image(70:150,5:55),image(80:145,55:130),image(80:155,130:175),image(80:155,175:225)};
figure;subplot(1,4,1), imshow(Objects{1});subplot(1,4,2), imshow(Objects{2});subplot(1,4,3); imshow(Objects{3}); subplot(1,4,4); imshow(Objects{4});
%Compute Shape analysis operations on reference characters
shadowDist = {sizeDistribution(Objects{1}),sizeDistribution(Objects{2}),sizeDistribution(Objects{3}),sizeDistribution(Objects{4})};
shadowPect = {Pecstrum(shadowDist{1}),Pecstrum(shadowDist{2}),Pecstrum(shadowDist{3}),Pecstrum(shadowDist{4})};
shadowComp(1:4) = [spectralComplexity(shadowPect{1}),spectralComplexity(shadowPect{2}),spectralComplexity(shadowPect{3}),spectralComplexity(shadowPect{4})];
%Manually extract objects in the rotated image
image = logical(imread('shadow1rotated.gif'));
ObjectsRotated = {image(10:75,5:80),image(10:85,80:125),image(10:85,125:175),image(15:85,175:235)...
    image(70:150,20:75),image(80:160,75:140),image(80:160,140:185),image(80:160,185:245)};
figure;subplot(1,4,1), imshow(ObjectsRotated{1});subplot(1,4,2), imshow(ObjectsRotated{2});subplot(1,4,3); imshow(ObjectsRotated{3}); subplot(1,4,4); imshow(ObjectsRotated{4});
figure;subplot(1,4,1), imshow(ObjectsRotated{5});subplot(1,4,2), imshow(ObjectsRotated{6});subplot(1,4,3); imshow(ObjectsRotated{7}); subplot(1,4,4); imshow(ObjectsRotated{8});
%Compute shape analysis operations on rotated image objects
rotatedDist = cell(8);
rotatedPect = cell(8);
rotatedComp(1:8) = 0;
for i = 1:8
    rotatedDist{i} = sizeDistribution(ObjectsRotated{i});
    rotatedPect{i} = Pecstrum(rotatedDist{i});
    rotatedComp(i) = spectralComplexity(rotatedPect{i});
end
%Calculated Comparison metrics for each set of objects
comparisonValues = cell(1,4);
C (1:40) = 1;

for i = 1:4
    %For each reference object, compute one set of comparison values
    comparisonValues{i} = zeros(8,3);
    for j = 1:8
        %First value is complexity difference
        comparisonValues{i}(j,1) = abs(shadowComp(i)-rotatedComp(j));
        %Second value is pecstral difference
        comparisonValues{i}(j,2) = pecstralDistance(shadowPect{i},rotatedPect{j},C);
    end
    %Third value is matching metric
    comparisonValues{i}(:,3) = (comparisonValues{i}(:,2)-mean(comparisonValues{i}(:,2)))/std(comparisonValues{i}(:,2))+...
        (comparisonValues{i}(:,1)-mean(comparisonValues{i}(:,1)))/std(comparisonValues{i}(:,1));
end
%Compute matches
iscomplete = 0;
mins(1:4) = 100;
matchvalue(1:4) = 10;
matchvalueFinal(1:4) = 0;
while ~iscomplete
    matchvalue
    for i = 1:8
        temp(1:4) = [comparisonValues{1}(i,3),comparisonValues{2}(i,3),comparisonValues{3}(i,3),comparisonValues{4}(i,3)];
        if temp(1) < mins(1)  && ~matchvalueFinal(1)
            mins(1) = temp(1);
            matchvalue(1) = i;
        end
        if temp(2) < mins(2)&& ~matchvalueFinal(2)
            mins(2) = temp(2);
            matchvalue(2) = i;
        end
        if temp(3) < mins(3)&& ~matchvalueFinal(3)
            mins(3) = temp(3);
            matchvalue(3) = i;
        end
        if temp(4) < mins(4)&& ~matchvalueFinal(4)
            mins(4) = temp(4);
            matchvalue(4) = i;
        end
    end
    %Check if there are overlapping matches
    if length(matchvalue) == length(unique(matchvalue))
       iscomplete = 1;
       for i = 1:4
           if ~matchvalueFinal(i)
               matchvalueFinal(i) = matchvalue(i);
           end
       end
    else
    %Select min value
        A = mins == min(mins);
    
        [row,column] = find(A);
        index = matchvalue(column);
        %Setting these values removes the selected column from competition
        %in next iteration of loop
        matchvalueFinal(column) = index;
        matchvalue(column) = column + 8;
        for i = 1:4    
            %Eliminate this index from contention for remaining cells
            comparisonValues{i}(index,3) = 10;
            %reset min value for next loop
            mins(i)  = 10;
        end
    end
end
%Display matches
for i = 1:4
    figure; 
    subplot(1,2,1); imshow(Objects{i}); 
    subplot(1,2,2); imshow(ObjectsRotated{matchvalueFinal(i)});
end



