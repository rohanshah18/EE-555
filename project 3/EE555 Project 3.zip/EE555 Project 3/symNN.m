function [ final ] = symNN(A)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
%symettric nearest neighbors mean
dimensions = size(A);
final = uint16(zeros(dimensions));
%zero pad A
B = padarray(A,[4,4],0,'both');
for m = 1:dimensions(1)
    for n = 1:dimensions(2)
        window = B(m:m+6,n:n+6);
        keyVal = window(4,4);
        sum = uint16(0);
        for i = 1:25
          k = mod(i,7) + 1;
          j = uint8(i/7) + 1;
          point1 = window(k,j);
          point2 = window(8-k,8-j);
            if abs(point1-keyVal) > point2-keyVal
                    sum = sum + uint16(point2);
            else
                    sum = sum + uint16(point1);
            end
        end
        final(m,n) = sum/25;
        end
end
end
