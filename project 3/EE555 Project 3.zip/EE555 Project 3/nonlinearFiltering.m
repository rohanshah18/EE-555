close all; clear;
A = imread('disk.gif');
figure; histogram(A);
title('Histogram of original disk image');
%7x7 median filter using medfilt2 function
B = medfilt2(A,[7,7]);
figure; imshow(B);
title('1 iteration of median filter');
figure; histogram(B);
title('Histogram of disk image after 1 iteration of median filter');
for i = 1:4
    B = medfilt2(B,[7,7]);
end
figure; imshow(B)
title('5 iterations of median filter');
figure; histogram(B);
title('Histogram of disk image after 5 iterations of median filter');
%7x7 alpha-trimmed mean filter
aTrimmed = alphaTrimmed(A,.25,49);
figure; imshow(aTrimmed);title('1 iteration of alpha trimmed mean filter');
figure; histogram(aTrimmed);
title('Histogram of disk image after 1 iteration of alpha trimmed mean filter');

for i = 2:5
    aTrimmed = alphaTrimmed(aTrimmed,.25,49);
end
figure; imshow(aTrimmed);title('5 iterations of alpha trimmed mean filter');
figure; histogram(aTrimmed);
title('Histogram of disk image after 5 iterations of alpha trimmed mean filter');
%sigma filtering
sigmaFilt = uint8(sigmaFilter(A,20));
figure; imshow(sigmaFilt);title('1 iteration of sigma filter with sigma = 20');
figure; histogram(sigmaFilt);
title('Histogram of disk image after 1 iteration of sigma filter');

for i = 2:5
    sigmaFilt = uint8(sigmaFilter(sigmaFilt,20));
end
figure; imshow(sigmaFilt);title('5 iterations of sigma filter with sigma = 20');
figure; histogram(sigmaFilt);
title('Histogram of disk image after 5 iterations of sigma filter');

%Symettric Nearest neighbors filtering
symFilt = uint8(symNN(A));
figure; imshow(symFilt);title('1 iteration of symmetric nearest neighbors mean filter');
figure; histogram(symFilt);
title('Histogram of disk image after 1 iteration of symettric nearest neighbors filter');
for i = 2:5
    symFilt = uint8(symNN(symFilt));
end
figure; imshow(symFilt);title('5 iterations of symmetric nearest neighbors mean filter');
figure; histogram(symFilt);
title('Histogram of disk image after 5 iterations of symettric nearest neighbors filter');
