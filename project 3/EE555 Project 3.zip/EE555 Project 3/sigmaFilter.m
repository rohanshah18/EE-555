function [ final ] = sigmaFilter( A,sigma )
%sigma filter, sigma = 20
%A = input image
%sigma = threshold for consideration
dimensions = size(A);
final = zeros(dimensions);
%zero pad A
B = padarray(A,[4,4],0,'both');
for m = 1:dimensions(1)
    for n = 1:dimensions(2)
        window = B(m:m+6,n:n+6);
        keyVal = window(4,4);
        sum = uint16(0);
        for i = 1:7
          for j = 1:7
            if abs(window(i,j)-keyVal) > 2*sigma
              window(i,j) = 0;
            else
              sum = sum + uint16(window(i,j));
            end
          end
        end
        Nc = nnz(window);
        final(m,n) = sum/Nc;
end
    end
end


