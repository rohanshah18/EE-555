function [ Z ] = alphaTrimmed(A, alpha, dimension)
%Computes alphaTrimmed mean on 2D image A
%   A = input image
%   alpha = parameter to determine # of discarded elements
%   dimension = parameter determining window size
alphaN = floor(alpha * dimension);
sum = 0;
Z = uint16(zeros(size(A)));
for i = 1 + alphaN: dimension - alphaN
    Z = Z + uint16(ordfilt2(A,i,ones(7)));
end
Z = uint8(Z./(49-2*alphaN));
end
